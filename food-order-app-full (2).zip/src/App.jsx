import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import UsersPage from './pages/UsersPage';
import FoodOrderPage from './pages/FoodOrderPage';
import AdminOrdersPage from './pages/AdminOrdersPage';

const user = JSON.parse(localStorage.getItem('currentUser'));

export default function App() {
  return (
    <Routes>
      <Route path='/' element={<Navigate to='/login' />} />
      <Route path='/login' element={<LoginPage />} />
      <Route path='/order' element={user ? <FoodOrderPage /> : <Navigate to='/login' />} />
      <Route path='/admin/orders' element={user?.role === 'admin' ? <AdminOrdersPage /> : <Navigate to='/login' />} />
      <Route path='/admin/users' element={user?.role === 'admin' ? <UsersPage /> : <Navigate to='/login' />} />
    </Routes>
  );
}
